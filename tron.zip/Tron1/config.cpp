#include "config.h"
#include <fstream>
#include <cstdlib>
#include <sys/stat.h>

static std::string config_dir() {
    const char* home = getenv("HOME");
    return std::string(home ? home : "/tmp") + "/.config/tron";
}

void Config::init() {
    std::string dir = config_dir();
    mkdir(dir.substr(0, dir.rfind('/')).c_str(), 0755);
    mkdir(dir.c_str(), 0755);
    load();
    load_scores();
}

static Config::Settings settings;
Config::Settings& Config::get() { return settings; }

void Config::save() {
    std::ofstream f(config_dir() + "/settings");
    if (!f) return;
    f << (int)settings.last_mode << ' ' << settings.tick_ms << '\n';
    for (int i = 0; i < 8; i++) {
        auto& sl = settings.slots[i];
        f << sl.human << ' ' << (int)sl.color << ' ' << sl.keyset
          << ' ' << (int)sl.diff << ' ' << sl.team << '\n';
    }
}

void Config::load() {
    std::ifstream f(config_dir() + "/settings");
    if (!f) {
        PColor cols[] = {PC_CYAN,PC_MAGENTA,PC_GREEN,PC_YELLOW,PC_RED,PC_BLUE,PC_WHITE,PC_ORANGE};
        for (int i=0;i<8;i++)
            settings.slots[i] = {i==0, cols[i], 0, AI_MED, i/2};
        return;
    }
    int m; f >> m >> settings.tick_ms;
    settings.last_mode = (GameMode)m;
    for (int i = 0; i < 8; i++) {
        int h, c, k, d, t;
        if (!(f >> h >> c >> k >> d >> t)) break;
        settings.slots[i] = {(bool)h, (PColor)c, k, (AIDiff)d, t};
    }
}

static ScoreData score_data;
ScoreData& Config::scores() { return score_data; }

void Config::save_scores() {
    std::ofstream f(config_dir() + "/scores");
    if (!f) return;
    auto& s = score_data;
    f << s.total_wins << ' ' << s.best_streak << ' ' << s.current_streak
      << ' ' << s.rounds_played << ' ' << s.best_time << ' ' << s.best_endless << '\n';
}

void Config::load_scores() {
    std::ifstream f(config_dir() + "/scores");
    if (!f) return;
    f >> score_data.total_wins >> score_data.best_streak >> score_data.current_streak
      >> score_data.rounds_played >> score_data.best_time >> score_data.best_endless;
}
